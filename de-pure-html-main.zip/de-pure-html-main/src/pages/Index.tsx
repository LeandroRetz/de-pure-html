import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Menu, X, Mail, Phone, MapPin, BarChart3, Database, Zap, Link, ChevronDown } from "lucide-react";

const Index = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    mensagem: ""
  });
  const { toast } = useToast();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsMenuOpen(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.nome || !formData.email || !formData.mensagem) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Mensagem enviada!",
      description: "Entraremos em contato em breve.",
    });

    setFormData({
      nome: "",
      email: "",
      mensagem: ""
    });
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="fixed top-0 left-0 w-full bg-background/95 backdrop-blur-sm border-b border-muted z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-foreground">
            DataSaúde <span className="text-primary">Inteligência</span>
          </h1>

          <nav className="hidden md:flex space-x-8">
            <button onClick={() => scrollToSection("inicio")} className="text-foreground hover:text-primary transition-colors">
              Início
            </button>
            <button onClick={() => scrollToSection("sobre")} className="text-foreground hover:text-primary transition-colors">
              Sobre
            </button>
            <button onClick={() => scrollToSection("servicos")} className="text-foreground hover:text-primary transition-colors">
              Serviços
            </button>
            <button onClick={() => scrollToSection("contato")} className="text-foreground hover:text-primary transition-colors">
              Contato
            </button>
          </nav>

          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          {isMenuOpen && (
            <nav className="absolute top-full left-0 w-full bg-background border-b border-muted md:hidden">
              <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
                <button onClick={() => scrollToSection("inicio")} className="text-left text-foreground hover:text-primary transition-colors">
                  Início
                </button>
                <button onClick={() => scrollToSection("sobre")} className="text-left text-foreground hover:text-primary transition-colors">
                  Sobre
                </button>
                <button onClick={() => scrollToSection("servicos")} className="text-left text-foreground hover:text-primary transition-colors">
                  Serviços
                </button>
                <button onClick={() => scrollToSection("contato")} className="text-left text-foreground hover:text-primary transition-colors">
                  Contato
                </button>
              </div>
            </nav>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section id="inicio" className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-background via-muted/30 to-background"></div>
        <div className="absolute top-20 right-20 w-32 h-32 bg-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-20 w-48 h-48 bg-primary/5 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto px-4 py-20 text-center relative z-10">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 text-foreground leading-tight">
              Transformamos dados em{" "}
              <span className="text-primary">decisões</span>{" "}
              na saúde pública
            </h1>
            
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 leading-relaxed">
              Especialistas em análise de dados, indicadores do SUS e automação de relatórios.
              Levamos inteligência de dados para gestores da saúde pública.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <Button 
                size="lg" 
                className="bg-primary text-primary-foreground hover:bg-primary/90 px-8 py-3 text-lg"
                onClick={() => scrollToSection("servicos")}
              >
                Nossos Serviços
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground px-8 py-3 text-lg"
                onClick={() => scrollToSection("contato")}
              >
                Fale Conosco
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">+500</div>
                <div className="text-muted-foreground">Relatórios Automatizados</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">+50</div>
                <div className="text-muted-foreground">Municípios Atendidos</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">98%</div>
                <div className="text-muted-foreground">Satisfação dos Clientes</div>
              </div>
            </div>
          </div>
          
          <button
            onClick={() => scrollToSection("sobre")}
            className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce"
          >
            <ChevronDown size={32} className="text-primary" />
          </button>
        </div>
      </section>

      {/* About Section */}
      <section id="sobre" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
                Sobre a DataSaúde Inteligência
              </h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Somos uma empresa especializada em transformar dados complexos da saúde pública 
                em informações estratégicas para gestores e profissionais do setor.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <h3 className="text-2xl font-bold mb-6 text-foreground">Nossa Missão</h3>
                <p className="text-lg text-muted-foreground mb-6">
                  Democratizar o acesso a informações de qualidade na saúde pública através 
                  de análises inteligentes de dados, indicadores do SUS e automações que 
                  otimizam a tomada de decisão.
                </p>
                <p className="text-lg text-muted-foreground">
                  Trabalhamos com dashboards avançados em Power BI, desenvolvimento de scripts 
                  Python para automatização, integração de APIs e criação de relatórios 
                  personalizados que facilitam a gestão em saúde.
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-card p-6 rounded-lg border border-border">
                  <BarChart3 className="w-12 h-12 text-primary mb-4" />
                  <h4 className="font-bold mb-2 text-foreground">Análise de Dados</h4>
                  <p className="text-sm text-muted-foreground">
                    Transformamos dados brutos em insights valiosos
                  </p>
                </div>
                
                <div className="bg-card p-6 rounded-lg border border-border">
                  <Database className="w-12 h-12 text-primary mb-4" />
                  <h4 className="font-bold mb-2 text-foreground">Indicadores SUS</h4>
                  <p className="text-sm text-muted-foreground">
                    Especialistas em indicadores de saúde pública
                  </p>
                </div>
                
                <div className="bg-card p-6 rounded-lg border border-border">
                  <Zap className="w-12 h-12 text-primary mb-4" />
                  <h4 className="font-bold mb-2 text-foreground">Automação</h4>
                  <p className="text-sm text-muted-foreground">
                    Scripts e processos automatizados
                  </p>
                </div>
                
                <div className="bg-card p-6 rounded-lg border border-border">
                  <Link className="w-12 h-12 text-primary mb-4" />
                  <h4 className="font-bold mb-2 text-foreground">Integrações</h4>
                  <p className="text-sm text-muted-foreground">
                    APIs e conexões entre sistemas
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="servicos" className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
                Nossos Serviços
              </h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Oferecemos soluções completas em Business Intelligence e análise de dados 
                especializadas para o setor de saúde pública.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
              <div className="bg-card p-8 rounded-lg border border-border hover:border-primary/30 transition-all duration-300 group">
                <div className="flex items-start space-x-4">
                  <div className="bg-primary/10 p-3 rounded-lg group-hover:bg-primary/20 transition-colors duration-300">
                    <BarChart3 className="w-8 h-8 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-3 text-foreground">
                      Dashboards Power BI
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      Desenvolvimento de painéis interativos e KPIs personalizados para gestão em saúde pública.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-card p-8 rounded-lg border border-border hover:border-primary/30 transition-all duration-300 group">
                <div className="flex items-start space-x-4">
                  <div className="bg-primary/10 p-3 rounded-lg group-hover:bg-primary/20 transition-colors duration-300">
                    <Link className="w-8 h-8 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-3 text-foreground">
                      Integrações via API
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      Conectamos diferentes sistemas e bases de dados para centralizar informações estratégicas.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-card p-8 rounded-lg border border-border hover:border-primary/30 transition-all duration-300 group">
                <div className="flex items-start space-x-4">
                  <div className="bg-primary/10 p-3 rounded-lg group-hover:bg-primary/20 transition-colors duration-300">
                    <Database className="w-8 h-8 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-3 text-foreground">
                      Indicadores SUS
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      Análise especializada dos principais indicadores de saúde pública e métricas do SUS.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-card p-8 rounded-lg border border-border hover:border-primary/30 transition-all duration-300 group">
                <div className="flex items-start space-x-4">
                  <div className="bg-primary/10 p-3 rounded-lg group-hover:bg-primary/20 transition-colors duration-300">
                    <Zap className="w-8 h-8 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-3 text-foreground">
                      Automação de Relatórios
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      Scripts Python e automações que otimizam processos e geram relatórios automaticamente.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contato" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
                Entre em Contato
              </h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Pronto para transformar os dados da sua instituição em decisões estratégicas? 
                Fale conosco e descubra como podemos ajudar.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div className="space-y-8">
                <div>
                  <h3 className="text-2xl font-bold mb-6 text-foreground">
                    Informações de Contato
                  </h3>
                  <div className="space-y-6">
                    <div className="flex items-center space-x-4">
                      <div className="bg-primary/10 p-3 rounded-lg">
                        <Mail className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <div className="font-semibold text-foreground">Email</div>
                        <div className="text-muted-foreground">contato@datasaude.com.br</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <div className="bg-primary/10 p-3 rounded-lg">
                        <Phone className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <div className="font-semibold text-foreground">Telefone</div>
                        <div className="text-muted-foreground">(11) 9999-8888</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <div className="bg-primary/10 p-3 rounded-lg">
                        <MapPin className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <div className="font-semibold text-foreground">Localização</div>
                        <div className="text-muted-foreground">São Paulo, SP - Brasil</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-card p-8 rounded-lg border border-border">
                <h3 className="text-2xl font-bold mb-6 text-foreground">
                  Envie sua Mensagem
                </h3>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="nome" className="block text-sm font-medium mb-2 text-foreground">
                      Nome Completo
                    </label>
                    <Input
                      id="nome"
                      name="nome"
                      type="text"
                      value={formData.nome}
                      onChange={handleInputChange}
                      placeholder="Seu nome completo"
                      className="w-full"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-2 text-foreground">
                      Email
                    </label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="seu@email.com"
                      className="w-full"
                    />
                  </div>

                  <div>
                    <label htmlFor="mensagem" className="block text-sm font-medium mb-2 text-foreground">
                      Mensagem
                    </label>
                    <Textarea
                      id="mensagem"
                      name="mensagem"
                      value={formData.mensagem}
                      onChange={handleInputChange}
                      placeholder="Descreva seu projeto ou necessidade..."
                      rows={5}
                      className="w-full"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                    size="lg"
                  >
                    Enviar Mensagem
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold mb-4">
                DataSaúde <span className="text-primary">Inteligência</span>
              </h3>
              <p className="text-background/80 mb-6 max-w-md mx-auto">
                Transformando dados em decisões na saúde pública através de 
                análises inteligentes e automações avançadas.
              </p>
            </div>

            <div className="border-t border-background/20 pt-8">
              <div className="text-center">
                <p className="text-background/60">
                  © 2024 DataSaúde Inteligência. Todos os direitos reservados.
                </p>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;