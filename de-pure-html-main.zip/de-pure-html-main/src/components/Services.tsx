import { BarChart3, Database, Zap, Link } from "lucide-react";
import { Button } from "@/components/ui/button";

const Services = () => {
  const services = [
    {
      icon: BarChart3,
      title: "Dashboards Power BI",
      description: "Desenvolvimento de painéis interativos e KPIs personalizados para gestão em saúde pública.",
      features: [
        "Dashboards interativos",
        "Automação de relatórios",
        "Visualizações personalizadas",
        "Integração com bases de dados"
      ]
    },
    {
      icon: Link,
      title: "Integrações via API",
      description: "Conectamos diferentes sistemas e bases de dados para centralizar informações estratégicas.",
      features: [
        "Integração SISAB/e-SUS",
        "APIs RESTful",
        "Sincronização de dados",
        "Pipelines automatizados"
      ]
    },
    {
      icon: Database,
      title: "Indicadores SUS",
      description: "Análise especializada dos principais indicadores de saúde pública e métricas do SUS.",
      features: [
        "Indicadores de pactuação",
        "Métricas de desempenho",
        "Análise de cobertura",
        "Relatórios de gestão"
      ]
    },
    {
      icon: Zap,
      title: "Automação de Relatórios",
      description: "Scripts Python e automações que otimizam processos e geram relatórios automaticamente.",
      features: [
        "Scripts Python personalizados",
        "Relatórios automatizados",
        "Processamento de dados",
        "Notificações inteligentes"
      ]
    }
  ];

  return (
    <section id="servicos" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
              Nossos Serviços
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Oferecemos soluções completas em Business Intelligence e análise de dados 
              especializadas para o setor de saúde pública.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            {services.map((service, index) => (
              <div 
                key={index}
                className="bg-card p-8 rounded-lg border border-border hover:border-primary/30 transition-all duration-300 group"
              >
                <div className="flex items-start space-x-4">
                  <div className="bg-primary/10 p-3 rounded-lg group-hover:bg-primary/20 transition-colors duration-300">
                    <service.icon className="w-8 h-8 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-3 text-foreground">
                      {service.title}
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      {service.description}
                    </p>
                    <ul className="space-y-2">
                      {service.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center text-sm text-muted-foreground">
                          <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-muted/30 p-8 rounded-lg text-center">
            <h3 className="text-2xl font-bold mb-4 text-foreground">
              Precisa de uma solução personalizada?
            </h3>
            <p className="text-lg text-muted-foreground mb-6">
              Desenvolvemos projetos sob medida para atender às necessidades específicas 
              da sua instituição de saúde.
            </p>
            <Button 
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={() => {
                const element = document.getElementById("contato");
                if (element) {
                  element.scrollIntoView({ behavior: "smooth" });
                }
              }}
            >
              Solicitar Orçamento
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;