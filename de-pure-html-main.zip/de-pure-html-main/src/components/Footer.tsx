import { Facebook, Instagram, Linkedin, Twitter } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-foreground text-background py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Company Info */}
            <div className="md:col-span-2">
              <h3 className="text-2xl font-bold mb-4">
                DataSaúde <span className="text-primary">Inteligência</span>
              </h3>
              <p className="text-background/80 mb-6 max-w-md">
                Transformando dados em decisões na saúde pública através de 
                análises inteligentes e automações avançadas.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-background/60 hover:text-primary transition-colors duration-300">
                  <Facebook size={24} />
                </a>
                <a href="#" className="text-background/60 hover:text-primary transition-colors duration-300">
                  <Instagram size={24} />
                </a>
                <a href="#" className="text-background/60 hover:text-primary transition-colors duration-300">
                  <Linkedin size={24} />
                </a>
                <a href="#" className="text-background/60 hover:text-primary transition-colors duration-300">
                  <Twitter size={24} />
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-lg font-semibold mb-4">Links Rápidos</h4>
              <ul className="space-y-2">
                <li>
                  <button 
                    onClick={() => {
                      const element = document.getElementById("inicio");
                      if (element) element.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="text-background/80 hover:text-primary transition-colors duration-300"
                  >
                    Início
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => {
                      const element = document.getElementById("sobre");
                      if (element) element.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="text-background/80 hover:text-primary transition-colors duration-300"
                  >
                    Sobre
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => {
                      const element = document.getElementById("servicos");
                      if (element) element.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="text-background/80 hover:text-primary transition-colors duration-300"
                  >
                    Serviços
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => {
                      const element = document.getElementById("contato");
                      if (element) element.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="text-background/80 hover:text-primary transition-colors duration-300"
                  >
                    Contato
                  </button>
                </li>
              </ul>
            </div>

            {/* Services */}
            <div>
              <h4 className="text-lg font-semibold mb-4">Serviços</h4>
              <ul className="space-y-2">
                <li className="text-background/80">Dashboards Power BI</li>
                <li className="text-background/80">Integrações via API</li>
                <li className="text-background/80">Indicadores SUS</li>
                <li className="text-background/80">Automação de Relatórios</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-background/20 mt-8 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-background/60 mb-4 md:mb-0">
                © 2024 DataSaúde Inteligência. Todos os direitos reservados.
              </p>
              <div className="flex space-x-6">
                <a href="#" className="text-background/60 hover:text-primary transition-colors duration-300">
                  Política de Privacidade
                </a>
                <a href="#" className="text-background/60 hover:text-primary transition-colors duration-300">
                  Termos de Uso
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;