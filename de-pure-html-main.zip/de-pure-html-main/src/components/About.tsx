import { BarChart3, Database, Users, Zap } from "lucide-react";

const About = () => {
  return (
    <section id="sobre" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
              Sobre a DataSaúde Inteligência
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Somos uma empresa especializada em transformar dados complexos da saúde pública 
              em informações estratégicas para gestores e profissionais do setor.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h3 className="text-2xl font-bold mb-6 text-foreground">Nossa Missão</h3>
              <p className="text-lg text-muted-foreground mb-6">
                Democratizar o acesso a informações de qualidade na saúde pública através 
                de análises inteligentes de dados, indicadores do SUS e automações que 
                otimizam a tomada de decisão.
              </p>
              <p className="text-lg text-muted-foreground">
                Trabalhamos com dashboards avançados em Power BI, desenvolvimento de scripts 
                Python para automatização, integração de APIs e criação de relatórios 
                personalizados que facilitam a gestão em saúde.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-6">
              <div className="bg-card p-6 rounded-lg border border-border">
                <BarChart3 className="w-12 h-12 text-primary mb-4" />
                <h4 className="font-bold mb-2 text-foreground">Análise de Dados</h4>
                <p className="text-sm text-muted-foreground">
                  Transformamos dados brutos em insights valiosos
                </p>
              </div>
              
              <div className="bg-card p-6 rounded-lg border border-border">
                <Database className="w-12 h-12 text-primary mb-4" />
                <h4 className="font-bold mb-2 text-foreground">Indicadores SUS</h4>
                <p className="text-sm text-muted-foreground">
                  Especialistas em indicadores de saúde pública
                </p>
              </div>
              
              <div className="bg-card p-6 rounded-lg border border-border">
                <Zap className="w-12 h-12 text-primary mb-4" />
                <h4 className="font-bold mb-2 text-foreground">Automação</h4>
                <p className="text-sm text-muted-foreground">
                  Scripts e processos automatizados
                </p>
              </div>
              
              <div className="bg-card p-6 rounded-lg border border-border">
                <Users className="w-12 h-12 text-primary mb-4" />
                <h4 className="font-bold mb-2 text-foreground">Consultoria</h4>
                <p className="text-sm text-muted-foreground">
                  Suporte especializado em BI e saúde
                </p>
              </div>
            </div>
          </div>

          <div className="bg-card p-8 rounded-lg border border-border">
            <h3 className="text-2xl font-bold mb-6 text-center text-foreground">
              Nossa Expertise
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">Power BI</div>
                <p className="text-sm text-muted-foreground">Dashboards interativos e automações</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">Python</div>
                <p className="text-sm text-muted-foreground">Scripts para análise e automação</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">APIs</div>
                <p className="text-sm text-muted-foreground">Integração de sistemas e dados</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">SUS</div>
                <p className="text-sm text-muted-foreground">Indicadores e métricas de saúde</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;